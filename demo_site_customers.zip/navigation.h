page_home(){

lr_start_transaction("Page->Home");

   	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=<input type=\"search\"",
		LAST);

	web_url("demosite.appvance.com", 
		"URL=http://{p_host_name}/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/bootstrap/glyphicons-halflings-regular-13634da87d9e23f8c3ed9108ce1724d183a39ad072e73e1b3d8cbf646d2d0407.eot?", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("cart_link", 
		"URL=http://{p_host_name}/cart_link", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_host_name}/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

    
	lr_end_transaction("Page->Home", LR_AUTO);
}

page_search(){   

	lr_start_transaction("Page->Search");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=<div data-hook=\"products_search_results_heading\">",
		LAST);
	
	web_reg_save_param("p_list_of_products",
		"LB=<a itemprop=\"url\" href=\"",
		"RB=\">",
		"Ord=All",
		"NotFound=WARNING",
		"Search=Body",
		LAST);

	web_url("products", 
		"URL=http://{p_host_name}/products?utf8=%E2%9C%93&taxon=&keywords={p_search_term}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_host_name}/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("cart_link_2", 
		"URL=http://{p_host_name}/cart_link", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_host_name}/products?utf8=%E2%9C%93&taxon=&keywords={p_search_term}", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/bootstrap/glyphicons-halflings-regular-13634da87d9e23f8c3ed9108ce1724d183a39ad072e73e1b3d8cbf646d2d0407.eot?", "Referer=http://{p_host_name}/products?utf8=%E2%9C%93&taxon=&keywords={p_search_term}", ENDITEM, 
		LAST);
	
	lr_end_transaction("Page->Search", LR_AUTO);
	
}

page_product(){

    lr_save_string(lr_paramarr_random("p_list_of_products"),"p_product");
    
	lr_start_transaction("Page->Product");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=<div data-hook=\"product_show\"",
		LAST);

	web_url("Spree-jr-spaghetti", 
		"URL=http://{p_host_name}{p_product}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_host_name}/products?utf8=%E2%9C%93&taxon=&keywords={p_search_term}", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/bootstrap/glyphicons-halflings-regular-13634da87d9e23f8c3ed9108ce1724d183a39ad072e73e1b3d8cbf646d2d0407.eot", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("cart_link_3", 
		"URL=http://{p_host_name}/cart_link", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_host_name}{p_product}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

    
	lr_end_transaction("Page->Product", LR_AUTO);
	
}

page_add_to_cart(){

	/*Add to Cart*/
    
	lr_start_transaction("Page->AddToCart");

	lr_end_transaction("Page->AddToCart", LR_AUTO);
}

page_checkout(){

	/*Checkout*/
    
	lr_start_transaction("Page->Checkout");

	lr_end_transaction("Page->Checkout", LR_AUTO);
	
}
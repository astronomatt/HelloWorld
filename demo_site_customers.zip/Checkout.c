Checkout()
{
    
	lr_start_transaction("UserFlow->Checkout");

	page_home();

	lr_think_time(10);

	page_search();

	lr_think_time(10);

	if(lr_paramarr_len("p_list_of_products") > 0){
    
		page_product();
	
		lr_think_time(10);
	
		page_add_to_cart();
	
		lr_think_time(10);
	
		page_checkout();
	
		lr_think_time(10);

	}
    
	lr_end_transaction("UserFlow->Checkout", LR_AUTO);


	return 0;
}

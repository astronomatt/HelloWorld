vuser_init()
{
	/******************************************
		SETTING TCP-LEVEL OPTIONS:
			* 	RETRY ON FAILURE
			* 	IGNORE LR ERROR REGARDING 
				PREMATURE CONNECTION SHUTDOWN
			* 	ISSUE WARNING FOR OVERLAPPED 
				DATA RATHER THAN FAILURE
	*******************************************/
	web_set_sockets_option("SSL_VERSION","TLS");
	web_set_max_retries("0");
    web_set_sockets_option ("IGNORE_PREMATURE_SHUTDOWN","1");
	web_set_sockets_option ("OVERLAPPED_SEND_FAILURE_AS_WARNING","1");

	/* Run-Time Argument */	
	lr_save_string(lr_get_attrib_string("HOST_NAME"),"p_host_name");

	return 0;
}

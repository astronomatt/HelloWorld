Abandonment()
{
	lr_start_transaction("UserFlow->Abandonment");

	page_home();

	lr_think_time(10);
	
	lr_end_transaction("UserFlow->Abandonment", LR_AUTO);


	return 0;
}
